# Grammalecte

**Correcteur grammatical pour le français**

écrit en JavaScript ES6/ES7
par Olivier R.

## Fonctionnalités ##

* correcteur grammatical
* conjugueur
* formateur de texte
* lexicographe
* éditeur lexical

## Site web ##

https://grammalecte.net

## Licence ##

GNU GPL 3.0+
http://www.gnu.org/copyleft/gpl.html
