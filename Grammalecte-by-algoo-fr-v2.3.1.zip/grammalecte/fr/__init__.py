"""
Grammalecte - core grammar checker engine
"""

from .gc_engine import *
